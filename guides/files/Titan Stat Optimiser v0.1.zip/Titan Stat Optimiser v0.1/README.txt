To use this, first do a "fully naked" parse, without any titan stats whatsoever. The longer, the better.
In order to run this, you'll also have to install Python.

NOTE: This program is provided as-is, without any guarantees that the results will be accurate or that it won't set your house on fire.
I do not take responsibility for any damages incurred as a result of using it.

Written by: quark27/IGN: Cyarel