from enum import IntEnum
from dataclasses import dataclass   

class TitanStat(IntEnum):
    DAMAGE_BOOST = 0
    DISCHARGE_BOOST = 1
    NORMAL_BOOST = 2
    SKILL_BOOST = 3
    WEAKPOINT_BOOST = 4

titan_multiplier = \
    [[1.0, 1.012, 1.016, 1.02, 1.024, 1.028, 1.0312, 1.0344, 1.0376, 1.0408,
      1.044, 1.0472, 1.0504, 1.0536, 1.0568, 1.06, 1.0632, 1.0664, 1.0696],
     [1.0, 1.08571, 1.11429, 1.14286, 1.17143, 1.2, 1.22286, 1.24571, 1.26857,
      1.29143, 1.3109, 1.3275, 1.3416, 1.3536, 1.3638, 1.3725, 1.3799, 1.3862,
      1.3916],
     [1.0, 1.05, 1.06667, 1.08333, 1.1, 1.11667, 1.13, 1.14333, 1.15667, 1.17,
      1.1833, 1.1966, 1.2099, 1.2232, 1.2345, 1.2441, 1.2523, 1.2593, 1.2653],
     [1.0, 1.04615, 1.06154, 1.07692, 1.09231, 1.10769, 1.12, 1.13231, 1.14462,
      1.15692, 1.1692, 1.1815, 1.1938, 1.2061, 1.2184, 1.2289, 1.2378, 1.2454,
      1.2519],
     [1.0, 1.03, 1.04, 1.05, 1.06, 1.07, 1.078, 1.086, 1.094, 1.102, 1.11,
      1.118, 1.126, 1.134, 1.142, 1.15, 1.158, 1.166, 1.174]]

class Piece(IntEnum):
    HELMET = 0
    VISOR = 1
    SPAULDERS = 2
    GLOVES = 3
    BRACERS = 4
    ARMOUR = 5
    ENGINE = 6
    BELT = 7
    PANTS = 8
    BOOTS = 9
    EXOSKELETON = 10
    MICROREACTOR = 11

titan_stat_from_piece = \
    [[TitanStat.NORMAL_BOOST, TitanStat.DAMAGE_BOOST,
      TitanStat.WEAKPOINT_BOOST],
     [TitanStat.NORMAL_BOOST, TitanStat.DISCHARGE_BOOST],
     [TitanStat.NORMAL_BOOST, TitanStat.DISCHARGE_BOOST,
      TitanStat.DAMAGE_BOOST, TitanStat.WEAKPOINT_BOOST],
     [TitanStat.NORMAL_BOOST, TitanStat.SKILL_BOOST,
      TitanStat.DAMAGE_BOOST, TitanStat.WEAKPOINT_BOOST],
     [TitanStat.SKILL_BOOST, TitanStat.DISCHARGE_BOOST,
      TitanStat.DAMAGE_BOOST, TitanStat.WEAKPOINT_BOOST],
     [TitanStat.DISCHARGE_BOOST, TitanStat.DAMAGE_BOOST,
      TitanStat.WEAKPOINT_BOOST],
     [TitanStat.SKILL_BOOST, TitanStat.DAMAGE_BOOST,
      TitanStat.WEAKPOINT_BOOST],
     [TitanStat.SKILL_BOOST],
     [TitanStat.NORMAL_BOOST],
     [TitanStat.NORMAL_BOOST, TitanStat.SKILL_BOOST],
     [TitanStat.SKILL_BOOST, TitanStat.DISCHARGE_BOOST],
     [TitanStat.DISCHARGE_BOOST]]

@dataclass
class TitanStatIndex:
    index = len(Piece) * [0]
    indexBound = [len(i) for i in titan_stat_from_piece]                       #

def increment_index(s):
    for i in Piece:
        s.index[i] += 1
        s.index[0:i] = i * [0]
        if(s.index[i] >= s.indexBound[i]):
            s.index[i] -= 1
        else:
            return 0
    return 1

def get_stat_list_from_index(s):
    stat = len(TitanStat) * [0]
    for i in Piece:
        stat[titan_stat_from_piece[i][s.index[i]]] += 3
    return stat

def typed_input(s, type):
    while(True):
        try:
            i = type(input(s))
            return i
        except ValueError:
            print("This doesn't seem to be a valid input. Please try again.")

def int_input(s):
    return typed_input(s, int)

def float_input(s):
    return typed_input(s, float)

def bool_input(s):
    i = input(s)
    if((not i) or i[0].lower() == 'y'):
        return True
    else:
        return False

print("Hint: You can input a number in millions or billions, or any other unit, as long as you keep it the same in all inputs.")
total_damage = float_input("Enter total damage dealt: ")
normal_damage = float_input("Enter normal damage dealt: ")/total_damage
skill_damage = float_input("Enter skill damage dealt: ")/total_damage
discharge_damage = float_input("Enter discharge damage dealt: ")/total_damage
other_damage = 1-normal_damage-skill_damage-discharge_damage

max_rank = int_input("How many titan stat combos should be kept track of? ")
weakpoint_is_on = bool_input("Should weakpoint be used? (Y/n): ")

best_multiplier = [1.0]
best_stat = [[0,0,0,0,0]]
while(True):
    stat = get_stat_list_from_index(TitanStatIndex)
    stat_multiplier = len(TitanStat) * [1.0]
    for i in TitanStat:
        stat_multiplier[i] = titan_multiplier[i][stat[i]]
    overall_multiplier = \
        (stat_multiplier[TitanStat.DAMAGE_BOOST]
         *(1.0 + weakpoint_is_on*(stat_multiplier[TitanStat.WEAKPOINT_BOOST] - 1.0))
         *(skill_damage*stat_multiplier[TitanStat.SKILL_BOOST]
           +normal_damage*stat_multiplier[TitanStat.NORMAL_BOOST]
           +discharge_damage*stat_multiplier[TitanStat.DISCHARGE_BOOST]
           +other_damage))
        
    rank = sum([overall_multiplier < mul for mul in best_multiplier])
    if(rank < len(best_stat) and best_stat[rank] != stat):
        best_multiplier.insert(rank, overall_multiplier)
        best_stat.insert(rank, stat)

    if len(best_multiplier) > max_rank:
        best_multiplier.pop()
        best_stat.pop()

    if(increment_index(TitanStatIndex)):
        break

for i in range(0, max_rank):
    print("Rank %d:" % (i + 1))
    print("Damage Boost: %d" % best_stat[i][TitanStat.DAMAGE_BOOST])
    print("Discharge Damage Boost: %d" % best_stat[i][TitanStat.DISCHARGE_BOOST])
    print("Skill Damage Boost: %d" % best_stat[i][TitanStat.SKILL_BOOST])
    print("Normal Damage Boost: %d" % best_stat[i][TitanStat.NORMAL_BOOST])
    print("Weakpoint Damage Boost: %d" % best_stat[i][TitanStat.WEAKPOINT_BOOST])
    print("Effective multiplier: %.3fx\n" % best_multiplier[i])

foo = input("Press enter to exit...")